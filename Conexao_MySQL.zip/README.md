# CRUD C# MySql
Projeto simples em 3 camadas com CRUD completo no C# 2015 com MySql

Para configurar seus dados de conexão com o MySql, edite o arquivo App.config e substitua os parâmetros referentes a Servidor, nome de usuario e senha pelos que estão configurados na seu MySql.

O projeto não está 100% orientado a objetos, mas para fins didáticos é muito útil.
